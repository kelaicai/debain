/*************************************************************************
	> File Name: http_redirection.h
	> Author: 
	> Mail: 
	> Created Time: 2018年07月29日 星期日 00时46分49秒
 ************************************************************************/

#ifndef _HTTP_REDIRECTION_H
#define _HTTP_REDIRECTION_H
#endif
#include"./configure.h"
extern bool http_redirection(int clientfd,int code,string myserver);


